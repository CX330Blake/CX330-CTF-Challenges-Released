# Challenge Info

This is a challenge that can let player knows more about the concept of private key in RSA encryption. It evaluates if the players know how to correctly generate a private key and use it to encrypt and decrypt messages.

# File struture

The `chal.py` and `output.txt` are the callenge file which can be handout to players. The flag is in the `secret.py` file & the solution is in the `solve.py` file.

# Final Thoughts

This is my first submission to HTB CTF. I hope it will be helpful for others. And also I help this can pass the internal evaluation! Thanks for reading this, see ya! Please contact me if you have any questions or concerns. You can find me on [my blog](https://blog.cx330.tw/about/) or [my Facebook](https://www.facebook.com/profile.php?id=100011698690769).
